﻿using FeatureFlowFramework.AppStructure;
using FeatureFlowFramework.Channels;
using FeatureFlowFramework.Helpers;
using FeatureFlowFramework.Logging;
using FeatureFlowFramework.Serialization;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace FeatureFlowFramework.DataShare
{
    public class ObjectsSynchronizer : IAppStructureElement
    {
        protected abstract class SharedData
        {
            public string uid;
            public object obj;
            public DateTime lastUpdated;
            public bool forcePushChanges = false;
            public int refCount = 1;
            public bool autoCheckForChanges = true;

            public SharedData(string uid, object obj, bool autoCheckForChanges, bool forcePushChanges)
            {
                this.uid = uid;
                this.obj = obj;
                this.autoCheckForChanges = autoCheckForChanges;
                this.forcePushChanges = forcePushChanges;
            }
        }

        protected class SharedNode : SharedData
        {
            public SharedNode(string uid, object obj, bool autoCheckForChanges, bool forcePushChanges) : base(uid, obj, autoCheckForChanges, forcePushChanges)
            {
            }

            public ISerializedObjComponent serializedObject = null;
            public ISerializedRefComponent serializedReferences = null;

            public bool UpdateSerializationIfLocalObjectChanged(ObjectsSynchronizer synchronizer, bool skipCheck = false)
            {
                bool changed = false;
                changed |= (serializedObject?.UpdateSerializationIfLocalObjectChanged(synchronizer, this, skipCheck)).FalseIfNull();
                changed |= (serializedReferences?.UpdateSerializationIfLocalObjectChanged(synchronizer, this, skipCheck)).FalseIfNull();
                return changed;
            }

            public bool UpdateLocalObjectFromSerialization(ObjectsSynchronizer synchronizer)
            {
                bool changed = false;
                changed |= (serializedObject?.UpdateLocalObjectFromSerialization(synchronizer, this)).FalseIfNull();
                changed |= (serializedReferences?.UpdateLocalObjectFromSerialization(synchronizer, this)).FalseIfNull();
                return changed;
            }
        }

        protected interface ISerializedComponent
        {
            bool UpdateSerializationIfLocalObjectChanged(ObjectsSynchronizer synchronizer, SharedNode node, bool skipCheck = false);
            bool UpdateLocalObjectFromSerialization(ObjectsSynchronizer synchronizer, SharedNode node);
        }

        protected interface ISerializedObjComponent : ISerializedComponent
        {
            string JsonObj { get; set; }
        }

        protected interface ISerializedRefComponent : ISerializedComponent
        {
            List<string> Refs { get; }
        }

        protected class SerializedObject : ISerializedObjComponent
        {
            string json = "{}";

            public string JsonObj { get => json; set => json = value; }

            public bool UpdateSerializationIfLocalObjectChanged(ObjectsSynchronizer synchronizer, SharedNode node, bool skipCheck = false)
            {                
                string newJson = Json.SerializeToJson(node.obj);
                if (skipCheck || newJson != json)
                {
                    json = newJson;
                    return true;
                }
                else return false;
            }

            public bool UpdateLocalObjectFromSerialization(ObjectsSynchronizer synchronizer, SharedNode node)
            {
                try
                {
                    Json.UpdateFromJson(node.obj, json);
                    return true;
                }
                catch (Exception e)
                {
                    synchronizer.Log.ERROR($"Deserializing json obj \"{node.uid}\" from storage failed!", e.ToString());
                    return false;
                }
            }
        }

        protected class SerializedCollectionReferences<T> : ISerializedRefComponent where T : class, new()
        {
            public List<string> itemIdList = new List<string>();
            public HashSet<object> itemsSet = new HashSet<object>();
            public List<object> itemsList = new List<object>(); 
            
            public List<string> Refs => itemIdList;

            public bool UpdateSerializationIfLocalObjectChanged(ObjectsSynchronizer synchronizer, SharedNode node, bool skipCheck = false)
            {
                ICollection<T> col = (node.obj as ICollection<T>);                
                if (!skipCheck)
                {
                    bool changed = false;
                    if (col.Count != itemIdList.Count) return false;
                    int i = 0;
                    foreach (var item in col)
                    {
                        if (!ReferenceEquals(itemsList[i], item))
                        {
                            changed = true;
                            break;
                        }
                        i++;
                    }

                    if (!changed) return false;
                }

                // Find and handle objects that were added or removed in original collection
                itemsList.Clear();
                foreach (object item in col)
                {
                    // itemsSet will be stripped by all existing objects in original to find the removed ones
                    if (!itemsSet.Remove(item))
                    {
                        // Check every object if already registered, otherwise register it
                        string uid = synchronizer.GetUidByObj_Node(item);
                        if (uid == null) uid = Guid.NewGuid().ToString();
                        synchronizer.RegisterNode(item, uid);
                    }
                    // itemsList will be refilled with all existing objects
                    itemsList.Add(item);
                }

                // Objects left in itemsSet were removed from original and will be unregistered
                foreach (object item in itemsSet)
                {
                    synchronizer.UnRegisterObject_Node(item);
                }

                // itemsSet and itemIdList will be updated to the actual state
                itemsSet.Clear();
                itemIdList.Clear();
                foreach (object item in itemsList)
                {
                    itemsSet.Add(item);
                    itemIdList.Add(synchronizer.GetUidByObj_Node(item));
                }

                return true;
            }

            public bool UpdateLocalObjectFromSerialization(ObjectsSynchronizer synchronizer, SharedNode node)
            {
                ICollection<T> col = (node.obj as ICollection<T>);

                itemsList.Clear();
                col.Clear();
                foreach (string itemId in itemIdList)
                {
                    T item = synchronizer.GetObjByUid_Node<T>(itemId);
                    if (item == null)
                    {
                        item = new T();
                    }
                    synchronizer.RegisterNode(item, itemId);
                    col.Add(item);
                    itemsList.Add(item);
                    itemsSet.Remove(item);
                }

                foreach (var item in itemsSet)
                {
                    synchronizer.UnRegisterObject_Node(item);
                }

                itemsSet.Clear();
                foreach (var item in itemsList)
                {
                    itemsSet.Add(item);
                }

                return true;
            }
        }

        protected class SharedObjData : SharedData
        {
            public string json = "{}";

            public SharedObjData(string uid, object obj, bool autoCheckForChanges, bool forcePushChanges) : base(uid, obj, autoCheckForChanges, forcePushChanges)
            {
                
            }
        }

        protected abstract class SharedCollectionData : SharedData
        {
            public List<string> itemIdList = new List<string>();
            public HashSet<object> itemsSet = new HashSet<object>();
            public List<object> itemsList = new List<object>();

            public SharedCollectionData(string uid, object obj, bool autoCheckForChanges, bool forcePushChanges) : base(uid, obj, autoCheckForChanges, forcePushChanges)
            {
            }

            public abstract bool CheckIfChanged();

            public abstract void UpdateFromOriginal(ObjectsSynchronizer synchronizer);

            internal abstract void UpdateFromItemIdList(ObjectsSynchronizer synchronizer);
        }

        protected class SharedCollectionData<T> : SharedCollectionData where T : class, new()
        {
            public SharedCollectionData(string uid, object obj, bool autoCheckForChanges, bool forcePushChanges) : base(uid, obj, autoCheckForChanges, forcePushChanges)
            {
            }

            public override bool CheckIfChanged()
            {
                ICollection<T> col = (obj as ICollection<T>);

                if (col.Count != itemIdList.Count) return true;

                int i = 0;
                foreach (var item in col)
                {
                    if (!ReferenceEquals(itemsList[i], item)) return true;
                    i++;
                }

                return false;
            }

            public override void UpdateFromOriginal(ObjectsSynchronizer synchronizer)
            {
                ICollection<T> col = (obj as ICollection<T>);

                // Find and handle objects that were added or removed in original collection
                itemsList.Clear();
                foreach (object item in col)
                {
                    // itemsSet will be stripped by all existing objects in original to find the removed ones
                    if (!itemsSet.Remove(item))
                    {
                        // Check every object if already registered, otherwise register it
                        string uid = synchronizer.GetUidByObj(item);
                        if (uid == null) uid = Guid.NewGuid().ToString();
                        synchronizer.RegisterObject(item, uid);
                    }
                    // itemsList will be refilled with all existing objects
                    itemsList.Add(item);
                }

                // Objects left in itemsSet were removed from original and will be unregistered
                foreach (object item in itemsSet)
                {
                    synchronizer.UnRegisterObject(item);
                }

                // itemsSet and itemIdList will be updated to the actual state
                itemsSet.Clear();
                itemIdList.Clear();
                foreach (object item in itemsList)
                {
                    itemsSet.Add(item);
                    itemIdList.Add(synchronizer.GetUidByObj(item));
                }
            }

            internal override void UpdateFromItemIdList(ObjectsSynchronizer synchronizer)
            {
                ICollection<T> col = (obj as ICollection<T>);

                itemsList.Clear();
                col.Clear();
                foreach (string itemId in itemIdList)
                {
                    T item = synchronizer.GetObjByUid<T>(itemId);
                    if (item == null)
                    {
                        item = new T();
                    }
                    synchronizer.RegisterObject(item, itemId);
                    col.Add(item);
                    itemsList.Add(item);
                    itemsSet.Remove(item);
                }

                foreach (var item in itemsSet)
                {
                    synchronizer.UnRegisterObject(item);
                }

                itemsSet.Clear();
                foreach (var item in itemsList)
                {
                    itemsSet.Add(item);
                }
            }
        }

        public FixedContextLogger Log = new FixedContextLogger();

        private Dictionary<string, SharedNode> uidToNode = new Dictionary<string, SharedNode>();
        private Dictionary<object, SharedNode> objToNode = new Dictionary<object, SharedNode>();
        private HashSet<SharedNode> changedNodes = new HashSet<SharedNode>();
        private List<string> latestUpdatedNodes = new List<string>();
        private List<string> latestRejectedNodes = new List<string>();
        private HashSet<SharedNode> nodesWithRefsToBeUpdated = new HashSet<SharedNode>();
        

        private AppStructureElementHelper appStructureElementHelper = new AppStructureElementHelper();
        private Dictionary<string, SharedObjData> uidToObjData = new Dictionary<string, SharedObjData>();
        private Dictionary<object, SharedObjData> objToObjData = new Dictionary<object, SharedObjData>();
        private HashSet<SharedObjData> changedObjects = new HashSet<SharedObjData>();
        private Dictionary<string, SharedCollectionData> uidToColData = new Dictionary<string, SharedCollectionData>();
        private Dictionary<object, SharedCollectionData> objToColData = new Dictionary<object, SharedCollectionData>();
        private HashSet<SharedCollectionData> changedCollections = new HashSet<SharedCollectionData>();
        private bool subscriptionChanges = false;
        private Sender<SyncRequestMessage> SyncRequestSender;
        private RoutingQueueReceiver<SyncResponseMessage> SyncResponseReceiver;
        private List<string> latestUpdatedObjects = new List<string>();
        private List<string> latestRejectedObjects = new List<string>();
        private List<string> latestUpdatedCollections = new List<string>();
        private List<string> latestRejectedCollections = new List<string>();
        private List<SyncResponseMessage> msgBuffer = new List<SyncResponseMessage>();
        private HashSet<SharedObjData> objectsToBeUpdated = new HashSet<SharedObjData>();
        private HashSet<SharedCollectionData> collectionsToBeUpdated = new HashSet<SharedCollectionData>();

        public WaitHandle WaitHandle => SyncResponseReceiver.WaitHandle;
        public IEnumerable<string> LatestUpdatedObjects => latestUpdatedObjects;
        public IEnumerable<string> LatestRejectedObjects => latestRejectedObjects;
        public IEnumerable<string> LatestUpdatedCollections => latestUpdatedCollections;
        public IEnumerable<string> LatestRejectedCollections => latestRejectedCollections;

        public string FullName => ((IAppStructureElement)appStructureElementHelper).FullName;

        public int OrderId => ((IAppStructureElement)appStructureElementHelper).OrderId;

        public string Name { get => ((IAppStructureElement)appStructureElementHelper).Name; set => ((IAppStructureElement)appStructureElementHelper).Name = value; }
        public string Description { get => ((IAppStructureElement)appStructureElementHelper).Description; set => ((IAppStructureElement)appStructureElementHelper).Description = value; }
        public IAppStructureElement Parent { get => ((IAppStructureElement)appStructureElementHelper).Parent; set => ((IAppStructureElement)appStructureElementHelper).Parent = value; }

        public ObjectsSynchronizer(string name = null, IAppStructureElement parent = null)
        {
            appStructureElementHelper.Init(this, name, parent);
            this.SyncResponseReceiver = new RoutingQueueReceiver<SyncResponseMessage>("SyncResponseReceiver", null, this);
            this.SyncRequestSender = new Sender<SyncRequestMessage>("SyncRequestSender", this);
        }

        public void ConnectToStorage(ISharedObjectsStorage storage)
        {
            this.SyncRequestSender.ConnectTo(storage.RequestReceiver);
            storage.ResponseSender.ConnectTo(this.SyncResponseReceiver);
        }

        public bool RegisterNode(object obj, string uid, bool autoCheckForChanges = true, bool forcePushChanges = false, bool ignoreRefCount = false)
        {
            var (success, existing) = FindExistingNode(obj, uid, ignoreRefCount);
            if (existing) return success;

            SharedNode node = new SharedNode(uid, obj, autoCheckForChanges, forcePushChanges)
            {
                serializedObject = new SerializedObject()
            };

            uidToNode[uid] = node;
            objToNode[obj] = node;

            MarkNodeAsChanged(node);            
            subscriptionChanges = true;
            return true;
        }

        public bool RegisterNode<T>(ICollection<T> obj, string uid, bool autoCheckForChanges = true, bool forcePushChanges = false, bool ignoreRefCount = false) where T : class, new()
        {
            var (success, existing) = FindExistingNode(obj, uid, ignoreRefCount);
            if (existing) return success;

            SharedNode node = new SharedNode(uid, obj, autoCheckForChanges, forcePushChanges)
            {
                serializedReferences = new SerializedCollectionReferences<T>()
            };

            uidToNode[uid] = node;
            objToNode[obj] = node;

            MarkNodeAsChanged(node);
            subscriptionChanges = true;            
            return true;
        }

        private (bool success, bool existing) FindExistingNode(object obj, string uid, bool ignoreRefCount)
        {            
            if (objToNode.TryGetValue(obj, out SharedNode objNode))
            {
                if (objNode.uid == uid)
                {
                    if (!ignoreRefCount) objNode.refCount++;
                    return (true, true);
                }
                else
                {
                    Log.ERROR($"Object with uid {uid} is already registered with another uid {objNode.uid}.");
                    return (false, true);
                }
            }
            else if (uidToNode.TryGetValue(uid, out SharedNode uidNode))
            {
                if (ReferenceEquals(uidNode.obj, obj))
                {
                    Log.ERROR($"Uid {uid} was found in uidToObjData but object was not found before in objToObjData! That should never happen!");
                    if (!ignoreRefCount) uidNode.refCount++;
                    return (true, true);
                }
                else
                {
                    Log.ERROR($"Uid {uid} is already used for another object.");
                    return (false, true);
                }
            }

            return (true, false);
        }


        public bool RegisterObject(object obj, string uid, bool autoCheckForChanges = true, bool forcePushChanges = false, bool ignoreRefCount = false)
        {
            if (objToObjData.TryGetValue(obj, out SharedObjData obj_objData))
            {
                if (obj_objData.uid == uid)
                {
                    if (!ignoreRefCount) obj_objData.refCount++;
                    return true;
                }
                else
                {
                    Log.ERROR($"Object with uid {uid} is already registered with another uid {obj_objData.uid}.");
                    return false;
                }
            }
            else if (uidToObjData.TryGetValue(uid, out SharedObjData uid_objData))
            {
                if (ReferenceEquals(uid_objData.obj, obj))
                {
                    Log.ERROR($"Uid {uid} was found in uidToObjData but object was not found before in objToObjData! That should never happen!");
                    if (!ignoreRefCount) obj_objData.refCount++;
                    return true;
                }
                else
                {
                    Log.ERROR($"Uid {uid} is already used for another object.");
                    return false;
                }
            }

            SharedObjData objData = new SharedObjData(uid, obj, autoCheckForChanges, forcePushChanges);
            uidToObjData[uid] = objData;
            objToObjData[obj] = objData;

            MarkObjectAsChanged(objData);            
            subscriptionChanges = true;
            return true;
        }

        public bool RegisterCollection<T>(ICollection<T> col, string uid, bool autoCheckForChanges = true, bool forcePushChanges = false) where T : class, new()
        {
            if (objToColData.TryGetValue(col, out SharedCollectionData obj_objData))
            {
                if (obj_objData.uid == uid)
                {
                    // everything is fine, do nothing.
                    return true;
                }
                else
                {
                    Log.ERROR($"Collection with uid {uid} is already registered with another uid {obj_objData.uid}.");
                    return false;
                }
            }
            else if (uidToColData.TryGetValue(uid, out SharedCollectionData uid_objData))
            {
                if (ReferenceEquals(uid_objData.obj, col))
                {
                    // everything is fine, do nothing.
                    return true;
                }
                else
                {
                    Log.ERROR($"Uid {uid} is already used for another collection.");
                    return false;
                }
            }

            SharedCollectionData colData = new SharedCollectionData<T>(uid, col, autoCheckForChanges, forcePushChanges) as SharedCollectionData;
            uidToColData[uid] = colData;
            objToColData[col] = colData;

            MarkCollectionAsChanged(colData);            
            subscriptionChanges = true;
            return true;
        }

        protected void UnRegisterNode(SharedNode node, bool ignoreRefCount = false)
        {
            if (node.refCount == 1 || (ignoreRefCount && node.refCount > 1))
            {
                node.refCount--;
                foreach (var nodeId in (node.serializedReferences?.Refs).EmptyIfNull())
                {
                    UnRegisterUid(nodeId);
                }

                uidToNode.Remove(node.uid);
                objToNode.Remove(node.obj);
                changedNodes.Remove(node);
                subscriptionChanges = true;
            }
            else if (node.refCount > 1)
            {             
                node.refCount--;
            }
        }

        public void UnRegisterObject_Node(object obj, bool ignoreRefCount = false)
        {
            if (objToNode.TryGetValue(obj, out SharedNode node))
            {
                UnRegisterNode(node, ignoreRefCount);
            }
        }

        public void UnRegisterUid(string uid, bool ignoreRefCount = false)
        {
            if (uidToNode.TryGetValue(uid, out SharedNode node))
            {
                UnRegisterNode(node, ignoreRefCount);
            }
        }

        protected void UnRegisterObject(SharedObjData data, bool ignoreRefCount = false)
        {
            if (ignoreRefCount || data.refCount <= 1)
            {
                uidToObjData.Remove(data.uid);
                objToObjData.Remove(data.obj);
                changedObjects.Remove(data);
                subscriptionChanges = true;
            }
            else
            {
                data.refCount--;
            }
        }

        protected void UnRegisterCollection(SharedCollectionData data)
        {
            if (data.refCount <= 1)
            {
                foreach (var itemId in data.itemIdList)
                {
                    UnRegisterObject(itemId);
                }
                uidToColData.Remove(data.uid);
                objToColData.Remove(data.obj);
                changedCollections.Remove(data);
                subscriptionChanges = true;
            }
            else
            {
                data.refCount--;
            }
        }

        public void UnRegisterObject(object obj, bool ignoreRefCount = false)
        {
            if (objToObjData.TryGetValue(obj, out SharedObjData objData))
            {
                UnRegisterObject(objData, ignoreRefCount);
            }
        }

        public void UnRegisterObject(string uid, bool ignoreRefCount = false)
        {
            if (uidToObjData.TryGetValue(uid, out SharedObjData objData))
            {
                UnRegisterObject(objData, ignoreRefCount);
            }
        }

        public void UnRegisterCollection(object col)
        {
            if (objToColData.TryGetValue(col, out SharedCollectionData colData))
            {
                UnRegisterCollection(colData);
            }
        }

        public void UnRegisterCollection(string uid)
        {
            if (uidToColData.TryGetValue(uid, out SharedCollectionData colData))
            {
                UnRegisterCollection(colData);
            }
        }

        public void UnRegisterAll()
        {
            uidToObjData.Clear();
            objToObjData.Clear();
            uidToColData.Clear();
            objToColData.Clear();
            changedObjects.Clear();
            changedCollections.Clear();

            subscriptionChanges = true;
        }

        public bool IsUidRegistered(string uid)
        {
            return uidToNode.ContainsKey(uid);
        }

        public bool IsObjRegistered_Node(object obj)
        {
            return objToNode.ContainsKey(obj);
        }

        public bool IsObjectRegistered(string uid)
        {
            return uidToObjData.ContainsKey(uid);
        }

        public bool IsObjectRegistered(object obj)
        {
            return objToObjData.ContainsKey(obj);
        }

        public bool IsCollectionRegistered(string uid)
        {
            return uidToColData.ContainsKey(uid);
        }

        public bool IsCollectionRegistered(object obj)
        {
            return objToColData.ContainsKey(obj);
        }

        public T GetObjByUid_Node<T>(string uid) where T : class
        {
            uidToNode.TryGetValue(uid, out var node);
            return node?.obj as T;
        }
        public string GetUidByObj_Node(object obj)
        {
            objToNode.TryGetValue(obj, out var node);
            return node?.uid;
        }


        public T GetObjByUid<T>(string uid) where T : class
        {
            uidToObjData.TryGetValue(uid, out var objData);
            return objData?.obj as T;
        }

        public string GetUidByObj(object obj)
        {
            objToObjData.TryGetValue(obj, out var objData);
            return objData?.uid;
        }

        public T GetCollectionByUid<T>(string uid) where T : class
        {
            uidToColData.TryGetValue(uid, out var objData);
            return objData?.obj as T;
        }

        public string GetUidByCollection(object col)
        {
            objToColData.TryGetValue(col, out var objData);
            return objData?.uid;
        }

        protected void MarkNodeAsChanged(SharedNode data)
        {
            changedNodes.Add(data);
        }

        public void MarkObjectAsChanged_Node(object obj)
        {
            if (objToNode.TryGetValue(obj, out SharedNode node))
            {
                MarkNodeAsChanged(node);
            }
        }

        public void MarkUidAsChanged(string uid)
        {
            if (uidToNode.TryGetValue(uid, out SharedNode node))
            {
                MarkNodeAsChanged(node);
            }
        }

        protected void MarkObjectAsChanged(SharedObjData data)
        {
            changedObjects.Add(data);
        }

        protected void MarkCollectionAsChanged(SharedCollectionData data)
        {
            changedCollections.Add(data);
        }

        public void MarkObjectAsChanged(object obj)
        {
            if (objToObjData.TryGetValue(obj, out SharedObjData objData))
            {
                MarkObjectAsChanged(objData);
            }
        }

        public void MarkObjectAsChanged(string uid)
        {
            if (uidToObjData.TryGetValue(uid, out SharedObjData objData))
            {
                MarkObjectAsChanged(objData);
            }
        }

        public void MarkCollectionAsChanged(object col)
        {
            if (objToColData.TryGetValue(col, out SharedCollectionData objData))
            {
                MarkObjectAsChanged(objData);
            }
        }

        public void MarkCollectionAsChanged(string uid)
        {
            if (uidToColData.TryGetValue(uid, out SharedCollectionData objData))
            {
                MarkObjectAsChanged(objData);
            }
        }

        protected void AutoCheckForChangesAndUpdateFromOriginal()
        {
            Parallel.ForEach(uidToNode.Values, (node) =>
            {
                if (node.autoCheckForChanges)
                {
                    if (node.UpdateSerializationIfLocalObjectChanged(this))
                    {
                        MarkNodeAsChanged(node);
                    }
                }
            });

            Parallel.ForEach(uidToColData.Values, (data) =>
            {
                if (data.autoCheckForChanges)
                {
                    if (data.CheckIfChanged())
                    {
                        data.UpdateFromOriginal(this);
                        lock (changedCollections)
                        {
                            MarkObjectAsChanged(data);
                        }
                    }
                }
            });

            Parallel.ForEach(uidToObjData.Values, (data) =>
            {
                if (data.autoCheckForChanges)
                {
                    string json = Json.SerializeToJson(data.obj);
                    if (json != data.json)
                    {
                        data.json = json;
                        lock (changedObjects)
                        {
                            MarkObjectAsChanged(data);
                        }
                    }
                }
            });
        }

        // Call this right after you executed your business logic
        public void PushAllChanges()
        {
            Parallel.ForEach(changedNodes, (node) =>
            {
                if (!node.autoCheckForChanges)
                {
                    node.UpdateSerializationIfLocalObjectChanged(this, true);
                }
            });

            Parallel.ForEach(changedCollections, (colData) =>
            {
                if (!colData.autoCheckForChanges)
                {
                    colData.UpdateFromOriginal(this);                    
                }
            });

            Parallel.ForEach(changedObjects, (objData) =>
            {
                if (!objData.autoCheckForChanges)
                {
                    string json = Json.SerializeToJson(objData.obj);
                    objData.json = json;
                }
            });

            AutoCheckForChangesAndUpdateFromOriginal();

            // DON'T SEND MESSAGE IF NO OBJECTS CHANGED AND SUBSCRIPTIONS DIDN'T CHANGE
            if (subscriptionChanges || changedNodes.Count !=0 || changedObjects.Count != 0 || changedCollections.Count != 0)
            {

                SyncRequestMessage msg = new SyncRequestMessage(FullName, SyncResponseReceiver.FullName, changedNodes.Count, changedObjects.Count, changedCollections.Count, uidToNode.Count ,uidToObjData.Count, uidToColData.Count);
                int i = 0;
                foreach (var objData in changedObjects)
                {
                    msg.changedObjects[i++] = new SyncRequestMessage.ChangedObj(objData.json, objData.uid, objData.lastUpdated, objData.forcePushChanges);
                }
                int j = 0;
                foreach (var colData in changedCollections)
                {
                    msg.changedCollections[j++] = new SyncRequestMessage.ChangedCollection(colData.uid, colData.lastUpdated, colData.itemIdList.ToArray(), colData.forcePushChanges);
                }

                int k = 0;
                foreach (var node in changedNodes)
                {
                    msg.changedNodes[k++] = new SyncRequestMessage.ChangedNode(node.uid, node.lastUpdated, node.forcePushChanges, node.serializedObject?.JsonObj, node.serializedReferences?.Refs.ToArray());
                }

                if (subscriptionChanges)
                {
                    msg.updateSubscriptions = true;
                    uidToNode.Keys.CopyTo(msg.nodeSubscriptions, 0);
                    uidToObjData.Keys.CopyTo(msg.objSubscriptions, 0);
                    uidToColData.Keys.CopyTo(msg.colSubscriptions, 0);
                }
                else
                {
                    msg.updateSubscriptions = false;
                }

                this.SyncRequestSender.Send(msg);

                changedNodes.Clear();
                changedObjects.Clear();
                changedCollections.Clear();
                subscriptionChanges = false;
            }
        }

        // Call this right before you execute your business logic
        public bool ApplyReceivedUpdates(bool collectLatestUpdateLists = false)
        {
            bool anyUpdatesReceived = false;

            Log.DEBUG($"Apply received updates. ({SyncResponseReceiver.Count} messages).");

            latestUpdatedNodes.Clear();
            latestRejectedNodes.Clear();

            latestUpdatedObjects.Clear();
            latestRejectedObjects.Clear();
            latestUpdatedCollections.Clear();
            latestRejectedCollections.Clear();

            while (SyncResponseReceiver.TryReceive(out SyncResponseMessage msg))
            {
                msgBuffer.Add(msg);
            }
            msgBuffer.Reverse();

            if (msgBuffer.Count > 0)
            {
                anyUpdatesReceived = true;
            }

            foreach (var msg in msgBuffer)
            {
                // first handle collections
                collectionsToBeUpdated.Clear();
                HandleReceivedCollections(msg, collectLatestUpdateLists);
                //HandleReceivedNodes(msg, collectLatestUpdateLists);

                //TODO: Nodes... 

                Parallel.ForEach(collectionsToBeUpdated, (myCol) =>
                {
                    myCol.UpdateFromItemIdList(this);
                });

                // second handle objects
                HandleReceivedObjects(msg, collectLatestUpdateLists);
            }

            Log.UpdateContext();
            Parallel.ForEach(objectsToBeUpdated, (myObj) =>
            {
                try
                {
                    Json.UpdateFromJson(myObj.obj, myObj.json);
                }
                catch (Exception e)
                {
                    Log.ERROR($"Deserializing json obj \"{myObj.uid}\" from storage failed!", e.ToString());
                }
            });

            objectsToBeUpdated.Clear();
            msgBuffer.Clear();

            if (latestRejectedObjects.Count > 0)
            {
                Log.WARNING($"The local changes of {latestRejectedObjects.Count} objects were rejected, due to newer versions in storage");
            }

            return anyUpdatesReceived;
        }

        private void HandleReceivedObjects(SyncResponseMessage msg, bool collectLatestUpdateLists)
        {
            foreach (var msgObj in msg.updatedObjects)
            {
                if (msgObj.pushRejected)
                {
                    latestRejectedObjects.Add(msgObj.uid);
                }

                if (uidToObjData.TryGetValue(msgObj.uid, out SharedObjData myData))
                {
                    if (myData is SharedObjData myObj)
                    {
                        if (msgObj.lastChange > myObj.lastUpdated)
                        {
                            myObj.lastUpdated = msgObj.lastChange;

                            if (msgObj.lastChanger != this.SyncResponseReceiver.FullName)
                            {
                                if (collectLatestUpdateLists) latestUpdatedObjects.Add(msgObj.uid);
                                myObj.json = msgObj.json;
                                objectsToBeUpdated.Add(myObj);
                            }
                        }
                    }
                    else
                    {
                        Log.ERROR($"Uid {msgObj.uid} of object from response message refers to local collection instead of object!");
                    }
                }
            }
        }

        private void HandleReceivedNodes(SyncResponseMessage.UpdatedNode[] msgNodes, bool collectLatestUpdateLists)
        {
            List<SyncResponseMessage.UpdatedNode> unhandledNodeChanges = null;
            bool retry = true;
            while (!msgNodes.EmptyOrNull() && retry)
            {
                foreach (var msgNode in msgNodes)
                {
                    if (msgNode.pushRejected)
                    {
                        latestRejectedNodes.Add(msgNode.uid);
                    }

                    if (uidToNode.TryGetValue(msgNode.uid, out SharedNode myNode))
                    {
                        if (msgNode.lastChange > myNode.lastUpdated)
                        {
                            myNode.lastUpdated = msgNode.lastChange;

                            if (msgNode.lastChanger != this.SyncResponseReceiver.FullName)
                            {
                                //TODO: Nodes...
                                if (collectLatestUpdateLists) latestUpdatedNodes.Add(msgNode.uid);
                                //myNode.itemIdList.Clear();
                                //myNode.itemIdList.AddRange(msgNode.referencedNodeIds);
                                nodesWithRefsToBeUpdated.Add(myNode);
                            }
                        }
                    }
                    else
                    {
                        if (unhandledNodeChanges == null) unhandledNodeChanges = new List<SyncResponseMessage.UpdatedNode>();
                        unhandledNodeChanges.Add(msgNode);
                    }
                }

                if (!unhandledNodeChanges.EmptyOrNull() && (msgNodes.Length > unhandledNodeChanges.Count))
                {
                    retry = true;
                    msgNodes = unhandledNodeChanges.ToArray();
                    unhandledNodeChanges.Clear();
                }
                else
                {
                    retry = false;
                }
            }
        }

        private void HandleReceivedCollections(SyncResponseMessage msg, bool collectLatestUpdateLists)
        {
            foreach (var msgCol in msg.updatedCollections)
            {
                if (msgCol.pushRejected)
                {
                    latestRejectedCollections.Add(msgCol.uid);
                }

                if (uidToColData.TryGetValue(msgCol.uid, out SharedCollectionData myCol))
                {
                    if (msgCol.lastChange > myCol.lastUpdated)
                    {
                        myCol.lastUpdated = msgCol.lastChange;

                        if (msgCol.lastChanger != this.SyncResponseReceiver.FullName)
                        {
                            if (collectLatestUpdateLists) latestUpdatedCollections.Add(msgCol.uid);
                            myCol.itemIdList.Clear();
                            myCol.itemIdList.AddRange(msgCol.objectIds);
                            collectionsToBeUpdated.Add(myCol);
                        }
                    }
                }
            }
        }

        public void Register()
        {
            ((IAppStructureElement)appStructureElementHelper).Register();
        }

        public void Unregister()
        {
            ((IAppStructureElement)appStructureElementHelper).Unregister();
        }

        public int GetNextChildOrderId(IAppStructureElement child)
        {
            return ((IAppStructureElement)appStructureElementHelper).GetNextChildOrderId(child);
        }
    }
}