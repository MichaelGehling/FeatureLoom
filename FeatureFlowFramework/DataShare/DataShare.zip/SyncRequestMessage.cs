﻿using System;

namespace FeatureFlowFramework.DataShare
{
    public class SyncRequestMessage
    {
        public string subscriberId;
        public string routingId;

        public ChangedNode[] changedNodes;
        public string[] nodeSubscriptions;

        public ChangedObj[] changedObjects;
        public ChangedCollection[] changedCollections;        
        public string[] objSubscriptions;
        public string[] colSubscriptions;

        public TimeSpan subscriptionTimeout = TimeSpan.FromMinutes(10);
        public TimeSpan subscriptionTimeoutWarning = TimeSpan.FromMinutes(9);
        public bool requestFullUpdate = false;
        public bool updateSubscriptions = true;

        public SyncRequestMessage(string subscriberId, string routingId, int numChangedNodes, int numChangedObjects, int numChangedCollections, int numNodeSubscriptions, int numObjSubscriptions, int numColSubscriptions)
        {
            this.subscriberId = subscriberId;
            this.routingId = routingId;
            changedNodes = new ChangedNode[numChangedNodes];
            nodeSubscriptions = new string[numNodeSubscriptions];

            changedObjects = new ChangedObj[numChangedObjects];
            changedCollections = new ChangedCollection[numChangedCollections];
            objSubscriptions = new string[numObjSubscriptions];
            colSubscriptions = new string[numColSubscriptions];
        }

        public struct ChangedNode
        {
            public string uid;
            public DateTime lastUpdated;
            public bool forcePushChanges;

            public string json;
            public string[] referencedNodeIds;

            public ChangedNode(string uid, DateTime lastUpdated, bool forcePushChanges, string json, string[] referencedNodeIds)
            {
                this.uid = uid;
                this.lastUpdated = lastUpdated;
                this.forcePushChanges = forcePushChanges;
                this.json = json;
                this.referencedNodeIds = referencedNodeIds;
            }
        }

        public struct ChangedObj
        {
            public string json;
            public string uid;
            public DateTime lastUpdated;
            public bool forcePushChanges;

            public ChangedObj(string json, string uid, DateTime lastUpdated, bool forcePushChanges)
            {
                this.json = json;
                this.uid = uid;
                this.lastUpdated = lastUpdated;
                this.forcePushChanges = forcePushChanges;
            }
        }

        public struct ChangedCollection
        {
            public string uid;
            public DateTime lastUpdated;
            public string[] objectIds;
            public bool forcePushChanges;

            public ChangedCollection(string uid, DateTime lastUpdated, string[] objectIds, bool forcePushChanges)
            {
                this.uid = uid;
                this.lastUpdated = lastUpdated;
                this.objectIds = objectIds;
                this.forcePushChanges = forcePushChanges;
            }
        }
    }
}