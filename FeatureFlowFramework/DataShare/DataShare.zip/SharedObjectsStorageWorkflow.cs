﻿using FeatureFlowFramework.AppStructure;
using FeatureFlowFramework.Channels;
using FeatureFlowFramework.Helpers;
using FeatureFlowFramework.Logging;
using FeatureFlowFramework.Workflows;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FeatureFlowFramework.DataShare
{
    public class SharedObjectsStorageWorkflow : Workflow, ISharedObjectsStorage
    {
        //TODO: Timeout is not implemented, yet!

        public QueueReceiver<SyncRequestMessage> requestReceiver;
        public RoutingSender<SyncResponseMessage> responseSender;
        private Dictionary<string, Subscriber> subscribers = new Dictionary<string, Subscriber>();
        private Dictionary<string, Node> nodes = new Dictionary<string, Node>();

        private Dictionary<string, SharedObject> sharedObjects = new Dictionary<string, SharedObject>();
        private Dictionary<string, SharedCollection> sharedCollections = new Dictionary<string, SharedCollection>();

        public SharedObjectsStorageWorkflow(string name = null, IAppStructureElement parent = null, ThreadMode threadMode = ThreadMode.NEW_BACKGROUND_THREAD) : base(name, parent, threadMode)
        {
        }

        public IChannelSink<SyncRequestMessage> RequestReceiver => requestReceiver;
        public IChannelSource<SyncResponseMessage> ResponseSender => responseSender;

        protected override void Init()
        {
            Init_robustStepExecution = true;
            Init_logStateTransitions = true;
            Init_logStepExecutions = true;

            this.requestReceiver = new QueueReceiver<SyncRequestMessage>("SyncRequestReceiver", this);
            this.responseSender = new RoutingSender<SyncResponseMessage>("SyncResponseSender", this);

            State starting = AddState("starting");
            State synchronizing = AddState("Synchronizing");

            starting
                ._Goto("Start synchronizing.", synchronizing);

            synchronizing
                ._WaitForAny("Wait for request messages.", () => requestReceiver.WaitHandle)
                ._Execute("Handle requests.", () => HandleRequests())
                ._Execute("Send responses.", () => SendResponses())
                ._Loop("Continue synchronizing.");
        }

        private void SendResponses()
        {
            Parallel.ForEach(subscribers.Values, (subscriber) =>
            {
                if (subscriber.nodeRejections.Count != 0 ||
                    subscriber.CountNodeUpdates() != 0 ||
                    subscriber.colRejections.Count != 0 ||
                    subscriber.objRejections.Count != 0 ||
                    subscriber.CountColUpdates() != 0 ||
                    subscriber.CountObjUpdates() != 0)
                {
                    SyncResponseMessage msg = CreateResponseMessage(subscriber);
                    responseSender.Send(msg);
                }
            });
        }

        private static SyncResponseMessage CreateResponseMessage(Subscriber subscriber)
        {
            SyncResponseMessage msg = new SyncResponseMessage(subscriber.id, subscriber.routingId, subscriber.CountObjUpdates() + subscriber.objRejections.Count, subscriber.CountColUpdates() + subscriber.colRejections.Count);
            int i = 0;
            foreach (var obj in subscriber.IterateObjUpdates())
            {
                msg.updatedObjects[i++] = new SyncResponseMessage.UpdatedObj(obj.uid, obj.json, obj.lastChange, obj.lastChanger, false);
            }
            foreach (var obj in subscriber.objRejections)
            {
                msg.updatedObjects[i++] = new SyncResponseMessage.UpdatedObj(obj.uid, obj.json, obj.lastChange, obj.lastChanger, true);
            }
            int j = 0;
            foreach (var col in subscriber.IterateColUpdates())
            {
                msg.updatedCollections[j++] = new SyncResponseMessage.UpdatedCollection(col.uid, col.objectIds.ToArray(), col.lastChange, col.lastChanger, false);
            }
            foreach (var col in subscriber.colRejections)
            {
                msg.updatedCollections[j++] = new SyncResponseMessage.UpdatedCollection(col.uid, col.objectIds.ToArray(), col.lastChange, col.lastChanger, true);
            }

            int k = 0;
            foreach (var node in subscriber.IterateNodeUpdates())
            {
                msg.updatedNodes[k++] = new SyncResponseMessage.UpdatedNode(node.uid, node.json, node.RefIds, node.lastChange, node.lastChanger, false);
            }
            foreach (var node in subscriber.nodeRejections)
            {
                msg.updatedNodes[k++] = new SyncResponseMessage.UpdatedNode(node.uid, node.json, node.RefIds, node.lastChange, node.lastChanger, false);
            }

            subscriber.ClearUpdates();
            subscriber.objRejections.Clear();
            subscriber.colRejections.Clear();
            subscriber.nodeRejections.Clear();
            return msg;
        }

        private void HandleRequests()
        {
            while (requestReceiver.TryReceive(out SyncRequestMessage msg))
            {
                HandleRequestMessage(msg);
            }
        }

        private void HandleRequestMessage(SyncRequestMessage msg)
        {
            DateTime timeStamp = DateTime.Now;
            Subscriber subscriber = FindOrCreateSubscriber(msg);
            subscriber.routingId = msg.routingId;

            if (!msg.changedNodes.EmptyOrNull()) ApplyChangedNodesOfRequester(msg, timeStamp, subscriber);

            if (!msg.changedObjects.EmptyOrNull()) ApplyChangedObjectsOfRequester(msg, timeStamp, subscriber);
            if (!msg.changedCollections.EmptyOrNull()) ApplyChangedCollectionsOfRequester(msg, timeStamp, subscriber);

            if (msg.updateSubscriptions)
            {
                UpdateNodeSubscriptionsOfRequester(msg, subscriber);

                UpdateObjectSubscriptionsOfRequester(msg, subscriber);
                UpdateCollectionSubscriptionsOfRequester(msg, subscriber);
            }

            subscriber.timeout = timeStamp + msg.subscriptionTimeout;
            subscriber.timeoutWarning = timeStamp + msg.subscriptionTimeoutWarning;

            if (msg.requestFullUpdate) MakeFullUpdateForRequester(subscriber);
        }

        private static void MakeFullUpdateForRequester(Subscriber subscriber)
        {
            foreach (var obj in subscriber.objSubscriptions.Values)
            {
                subscriber.AddObjUpdate(obj);
            }

            foreach (var col in subscriber.colSubscriptions.Values)
            {
                subscriber.AddColUpdate(col);
            }
        }


        private void UpdateNodeSubscriptionsOfRequester(SyncRequestMessage msg, Subscriber subscriber)
        {
            if (msg.nodeSubscriptions.EmptyOrNull())
            {
                foreach (var nodePair in subscriber.nodeSubscriptions)
                {
                    nodePair.Value.subscribers.Remove(subscriber);
                    if (nodePair.Value.subscribers.Count == 0)
                    {
                        nodes.Remove(nodePair.Key);
                    }
                }
                subscriber.nodeSubscriptions.Clear();
                return;
            }

            List<string> newSubs = new List<string>();
            foreach (var uid in msg.nodeSubscriptions)
            {
                if (!subscriber.nodeSubscriptions.ContainsKey(uid))
                {
                    newSubs.Add(uid);
                }
            }
            int numUidsMissed = 0;
            foreach (var uid in newSubs)
            {
                if (nodes.TryGetValue(uid, out Node node))
                {
                    subscriber.nodeSubscriptions.Add(uid, node);
                    subscriber.AddNodeUpdate(node);
                    node.subscribers.Add(subscriber);
                }
                else
                {
                    Log.WARNING($"UID {uid} requested for node subscription by {subscriber.id} cannot be found!");
                    numUidsMissed++;
                }
            }
            
            // Some Nodes were removed?
            if (subscriber.nodeSubscriptions.Count > (msg.nodeSubscriptions.Length - numUidsMissed))
            {
                Dictionary<string, Node> removeSubscriptions = new Dictionary<string, Node>(subscriber.nodeSubscriptions);
                foreach (var uid in msg.nodeSubscriptions)
                {
                    removeSubscriptions.Remove(uid);
                }
                foreach (var nodePair in removeSubscriptions)
                {
                    subscriber.nodeSubscriptions.Remove(nodePair.Key);
                    nodePair.Value.subscribers.Remove(subscriber);
                    if (nodePair.Value.subscribers.Count == 0)
                    {
                        nodes.Remove(nodePair.Value.uid);
                    }
                }
            }
        }


        private void UpdateObjectSubscriptionsOfRequester(SyncRequestMessage msg, Subscriber subscriber)
        {
            List<string> newSubs = new List<string>();
            foreach (var uid in msg.objSubscriptions)
            {
                if (!subscriber.objSubscriptions.ContainsKey(uid))
                {
                    newSubs.Add(uid);
                }
            }
            int numUidsMissed = 0;
            foreach (var uid in newSubs)
            {
                if (sharedObjects.TryGetValue(uid, out SharedObject obj))
                {
                    subscriber.objSubscriptions.Add(uid, obj);
                    subscriber.AddObjUpdate(obj);
                    obj.subscribers.Add(subscriber);
                }
                else
                {
                    Log.WARNING($"UID {uid} requested for object subscription by {subscriber.id} cannot be found!");
                    numUidsMissed++;
                }
            }
            if (subscriber.objSubscriptions.Count > (msg.objSubscriptions.Length - numUidsMissed))
            {
                HashSet<string> removeUids = new HashSet<string>(subscriber.objSubscriptions.Keys);
                foreach (var uid in msg.objSubscriptions)
                {
                    removeUids.Remove(uid);
                }
                foreach (var removeUid in removeUids)
                {
                    subscriber.objSubscriptions.Remove(removeUid);
                    if (sharedObjects.TryGetValue(removeUid, out SharedObject obj))
                    {
                        obj.subscribers.Remove(subscriber);
                        if (obj.subscribers.Count == 0)
                        {
                            sharedObjects.Remove(obj.uid);
                        }
                    }
                }
            }
        }        

        private void UpdateCollectionSubscriptionsOfRequester(SyncRequestMessage msg, Subscriber subscriber)
        {
            List<string> newSubs = new List<string>();
            foreach (var uid in msg.colSubscriptions)
            {
                if (!subscriber.colSubscriptions.ContainsKey(uid))
                {
                    newSubs.Add(uid);
                }
            }
            int numUidsMissed = 0;
            foreach (var uid in newSubs)
            {
                if (sharedCollections.TryGetValue(uid, out SharedCollection col))
                {
                    subscriber.colSubscriptions.Add(uid, col);
                    subscriber.AddColUpdate(col);
                    col.subscribers.Add(subscriber);

                    foreach (var obj in col.objects)
                    {
                        if (subscriber.objSubscriptions.TryAdd(obj.uid, obj))
                        {
                            subscriber.AddObjUpdate(obj);
                        }
                    }
                }
                else
                {
                    Log.WARNING($"UID {uid} requested for collection subscription by {subscriber.id} cannot be found!");
                    numUidsMissed++;
                }
            }
            if (subscriber.colSubscriptions.Count > (msg.colSubscriptions.Length - numUidsMissed))
            {
                HashSet<string> removeUids = new HashSet<string>(subscriber.colSubscriptions.Keys);
                foreach (var uid in msg.colSubscriptions)
                {
                    removeUids.Remove(uid);
                }
                foreach (var removeUid in removeUids)
                {
                    subscriber.colSubscriptions.Remove(removeUid);
                    if (sharedCollections.TryGetValue(removeUid, out SharedCollection col))
                    {
                        col.subscribers.Remove(subscriber);
                        if (col.subscribers.Count == 0)
                        {
                            sharedObjects.Remove(col.uid);
                        }
                    }
                }
            }
        }

        private void ApplyChangedNodesOfRequester(SyncRequestMessage msg, DateTime timeStamp, Subscriber subscriber)
        {
            foreach (var changedNode in msg.changedNodes.EmptyIfNull())
            {
                if (!nodes.TryGetValue(changedNode.uid, out Node node))
                {
                    node = new Node(changedNode.uid, timeStamp, subscriber.id, nodes)
                    {
                        json = changedNode.json,
                        RefIds = changedNode.referencedNodeIds
                    };
                    nodes.Add(changedNode.uid, node);
                }
                else
                {
                    if (changedNode.lastUpdated >= node.lastChange || changedNode.forcePushChanges)
                    {
                        bool changed = false;
                        bool refChanged = false;

                        if (node.CheckForChangedRefs(changedNode.referencedNodeIds))
                        {
                            node.RefIds = changedNode.referencedNodeIds;
                            changed = true;
                            refChanged = true;
                        }

                        if (node.json != changedNode.json)
                        {
                            node.json = changedNode.json;
                            changed = true;
                        }

                        if (changed)
                        {
                            node.lastChange = timeStamp;
                            node.lastChanger = msg.subscriberId;
                            // collect accepted changes to send to subscribers
                            foreach (var nodeSubscriber in node.subscribers)
                            {
                                nodeSubscriber.AddNodeUpdate(node);
                                if (refChanged)
                                {
                                    // check for every obj in collection if subscriber already subscribes it
                                    // if not, add subscription and update request
                                    foreach (var refNode in node.RefNodes)
                                    {
                                        if (subscriber.nodeSubscriptions.TryAdd(refNode.uid, refNode))
                                        {
                                            subscriber.AddNodeUpdate(refNode);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void ApplyChangedCollectionsOfRequester(SyncRequestMessage msg, DateTime timeStamp, Subscriber subscriber)
        {
            foreach (var changedCol in msg.changedCollections.EmptyIfNull())
            {
                if (!sharedCollections.TryGetValue(changedCol.uid, out SharedCollection col))
                {
                    col = new SharedCollection(changedCol.objectIds, changedCol.uid, timeStamp, subscriber.id, sharedObjects);
                    sharedCollections.Add(changedCol.uid, col);
                }
                else
                {
                    if ((changedCol.lastUpdated >= col.lastChange || changedCol.forcePushChanges) &&
                        col.DiffersFrom(changedCol.objectIds))
                    {
                        col.objectIds.Clear();
                        col.objectIds.AddRange(changedCol.objectIds);
                        col.UpdateObjectsFromIds(sharedObjects);
                        col.lastChange = timeStamp;
                        col.lastChanger = msg.subscriberId;
                        // collect accepted changes to send to subscribers
                        foreach (var colSubscriber in col.subscribers)
                        {
                            colSubscriber.AddColUpdate(col);

                            // check for every obj in collection if subscriber already subscribes it
                            // if not, add subscription and update request
                            foreach (var obj in col.objects)
                            {
                                subscriber.objSubscriptions.TryAdd(obj.uid, obj);
                                subscriber.AddObjUpdate(obj);
                            }
                        }
                    }
                    else
                    {
                        if (changedCol.lastUpdated != default)
                        {
                            // collect rejected changes to send to requester
                            subscriber.colRejections.Add(col);
                        }
                    }
                }
            }
        }

        private void ApplyChangedObjectsOfRequester(SyncRequestMessage msg, DateTime timeStamp, Subscriber subscriber)
        {
            foreach (var changedObj in msg.changedObjects.EmptyIfNull())
            {
                if (!sharedObjects.TryGetValue(changedObj.uid, out SharedObject obj))
                {
                    obj = new SharedObject(changedObj.uid, changedObj.json, timeStamp, subscriber.id);
                    sharedObjects.Add(changedObj.uid, obj);
                }
                else
                {
                    if ((changedObj.lastUpdated >= obj.lastChange || changedObj.forcePushChanges) &&
                        changedObj.json != obj.json)
                    {
                        obj.json = changedObj.json;
                        obj.lastChange = timeStamp;
                        obj.lastChanger = msg.subscriberId;
                        // collect accepted changes to send to subscribers
                        foreach (var objSubscriber in obj.subscribers)
                        {
                            objSubscriber.AddObjUpdate(obj);
                        }
                    }
                    else
                    {
                        if (changedObj.lastUpdated != default)
                        {
                            // collect rejected changes to send to requester
                            subscriber.objRejections.Add(obj);
                        }
                    }
                }
            }
        }

        private Subscriber FindOrCreateSubscriber(SyncRequestMessage msg)
        {
            if (!subscribers.TryGetValue(msg.subscriberId, out Subscriber subscriber))
            {
                subscriber = new Subscriber(msg.subscriberId, msg.routingId);
                subscribers.Add(msg.subscriberId, subscriber);
            }

            return subscriber;
        }

        private class Node
        {
            public string json = null;
            private NodeReferences nodeRefs = null;
            public List<Subscriber> subscribers = null;
            readonly Dictionary<string, Node> nodeDict;

            public string uid;            
            public DateTime lastChange;
            public string lastChanger;

            public Node(string uid, DateTime lastChange, string lastChanger, Dictionary<string, Node> nodeDict)
            {
                this.uid = uid;
                this.lastChange = lastChange;
                this.lastChanger = lastChanger;
                this.nodeDict = nodeDict;
            }

            public bool CheckForChangedRefs(string[] otherRefIds)
            {
                if (otherRefIds.EmptyOrNull() && nodeRefs != null && !nodeRefs.Ids.EmptyOrNull()) return true;
                if (!otherRefIds.EmptyOrNull() && (nodeRefs == null || nodeRefs.Ids.EmptyOrNull())) return true;
                return nodeRefs.CheckForDifferences(otherRefIds);
            }

            public Node[] RefNodes => nodeRefs?.Nodes;

            public string[] RefIds
            {
                get
                {
                    if (nodeRefs == null) return null;
                    else return nodeRefs.Ids;
                }
                set
                {
                    if (nodeRefs == null)
                    {
                        if (!value.EmptyOrNull())
                        {
                            nodeRefs = new NodeReferences(value, nodeDict);
                        }
                    }
                    else
                    {
                        if (value.EmptyOrNull())
                        {
                            nodeRefs = null;
                        }
                        else
                        {
                            nodeRefs.Ids = value;
                            nodeRefs.UpdateNodesFromIds(nodeDict);
                        }
                    }
                }
            }            
        }

        class NodeReferences
        {
            private string[] ids;
            private Node[] nodes;

            public NodeReferences(string[] ids, Dictionary<string, Node> nodeDict)
            {
                this.ids = ids;
                UpdateNodesFromIds(nodeDict);
            }

            public string[] Ids
            {
                get => ids;
                set => ids = value;
            }
            public Node[] Nodes => nodes;

            public bool CheckForDifferences(string[] otherRefIds)
            {
                if (otherRefIds.Length != ids.Length) return true;
                else
                {
                    for (int i = otherRefIds.Length - 1; i >= 0; i--)
                    {
                        if (otherRefIds[i] != ids[i]) return true;
                    }
                }
                return false;
            }

            public void UpdateNodesFromIds(Dictionary<string, Node> nodeDict)
            {                
                if (nodes.Length != ids.Length) nodes = new Node[this.ids.Length];

                for (int i=0; i < ids.Length; i++)
                {
                    if (nodeDict.TryGetValue(ids[i], out Node node))
                    {
                        nodes[i] = node;
                    }
                    else
                    {
                        nodes[i] = null;
                        Log.ERROR($"Node with Id {ids[i]} cannot be found for reference!");
                    }
                }
            }
        }

        private class SharedObject
        {
            public string uid;
            public string json;
            public DateTime lastChange;
            public string lastChanger;
            public List<Subscriber> subscribers = new List<Subscriber>();

            public SharedObject(string uid, string json, DateTime lastChange, string lastChanger)
            {
                this.uid = uid;
                this.json = json;
                this.lastChange = lastChange;
                this.lastChanger = lastChanger;
            }
        }

        private class SharedCollection
        {
            public List<string> objectIds = new List<string>();
            public List<SharedObject> objects = new List<SharedObject>();
            public string uid;
            public DateTime lastChange;
            public string lastChanger;
            public List<Subscriber> subscribers = new List<Subscriber>();

            public SharedCollection(string[] objIds, string uid, DateTime lastChange, string lastChanger, Dictionary<string, SharedObject> sharedObjects)
            {
                this.uid = uid;
                this.lastChange = lastChange;
                this.lastChanger = lastChanger;
                this.objectIds.AddRange(objIds);
                UpdateObjectsFromIds(sharedObjects);
            }

            public bool DiffersFrom(string[] objIds)
            {
                if (objIds.Length != objectIds.Count) return true;
                else
                {
                    for (int i = objIds.Length - 1; i >= 0; i--)
                    {
                        if (objIds[i] != objectIds[i]) return true;
                    }
                }
                return false;
            }

            internal void UpdateObjectsFromIds(Dictionary<string, SharedObject> sharedObjects)
            {
                objects.Clear();
                foreach (var objId in objectIds)
                {
                    if (sharedObjects.TryGetValue(objId, out SharedObject obj))
                    {
                        objects.Add(obj);
                    }
                }
            }
        }

        private class Subscriber
        {
            public string id;
            public string routingId;

            public DateTime timeout;
            public DateTime timeoutWarning;

            public Dictionary<string, Node> nodeSubscriptions = new Dictionary<string, Node>();
            public List<Node> nodeRejections = new List<Node>();
            private HashSet<Node> nodeUpdatesSet = new HashSet<Node>();
            private List<Node> nodeUpdates = new List<Node>();

            public Dictionary<string, SharedObject> objSubscriptions = new Dictionary<string, SharedObject>();
            public Dictionary<string, SharedCollection> colSubscriptions = new Dictionary<string, SharedCollection>();

            public List<SharedObject> objRejections = new List<SharedObject>();
            public List<SharedCollection> colRejections = new List<SharedCollection>();

            private HashSet<SharedObject> objUpdatesSet = new HashSet<SharedObject>();
            private List<SharedObject> objUpdates = new List<SharedObject>();
            private HashSet<SharedCollection> colUpdatesSet = new HashSet<SharedCollection>();
            private List<SharedCollection> colUpdates = new List<SharedCollection>();

            public Subscriber(string id, string routingId)
            {
                this.id = id;
                this.routingId = routingId;
            }

            public void AddNodeUpdate(Node node)
            {
                if (nodeUpdatesSet.Add(node))
                {
                    nodeUpdates.Add(node);
                }
            }

            public void ClearUpdates()
            {
                nodeUpdates.Clear();
                nodeUpdatesSet.Clear();

                objUpdates.Clear();
                objUpdatesSet.Clear();
                colUpdates.Clear();
                colUpdatesSet.Clear();
            }

            public int CountNodeUpdates()
            {
                return nodeUpdates.Count;
            }

            public IEnumerable<Node> IterateNodeUpdates()
            {
                return nodeUpdates;
            }



            public void AddObjUpdate(SharedObject obj)
            {
                if (objUpdatesSet.Add(obj))
                {
                    objUpdates.Add(obj);
                }
            }

            public void AddColUpdate(SharedCollection col)
            {
                if (colUpdatesSet.Add(col))
                {
                    colUpdates.Add(col);
                }
            }
           
            public int CountObjUpdates()
            {
                return objUpdates.Count;
            }

            public int CountColUpdates()
            {
                return colUpdates.Count;
            }

            public IEnumerable<SharedObject> IterateObjUpdates()
            {
                return objUpdates;
            }

            public IEnumerable<SharedCollection> IterateColUpdates()
            {
                return colUpdates;
            }
        }
    }
}