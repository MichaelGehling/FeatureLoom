﻿using FeatureFlowFramework.Channels;

namespace FeatureFlowFramework.DataShare
{
    public interface ISharedObjectsStorage
    {
        IChannelSink<SyncRequestMessage> RequestReceiver { get; }
        IChannelSource<SyncResponseMessage> ResponseSender { get; }
    }
}