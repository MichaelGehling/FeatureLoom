﻿using FeatureFlowFramework.Channels;
using System;

namespace FeatureFlowFramework.DataShare
{
    public class SyncResponseMessage : IRoutable
    {
        public string subscriberId;
        public string routingId;
        public UpdatedObj[] updatedObjects;
        public UpdatedCollection[] updatedCollections;
        public UpdatedNode[] updatedNodes;

        public SyncResponseMessage(string subscriberId, string routingId, int numUpdatedObjects, int numUpdatedCollections)
        {
            this.subscriberId = subscriberId;
            this.routingId = routingId;
            updatedObjects = new UpdatedObj[numUpdatedObjects];
            updatedCollections = new UpdatedCollection[numUpdatedCollections];
        }

        public string RoutingId => routingId;

        public struct UpdatedNode
        {
            public string uid;
            public string json;
            public string[] referencedNodeIds;
            public DateTime lastChange;
            public string lastChanger;
            public bool pushRejected;

            public UpdatedNode(string uid, string json, string[] referencedNodeIds, DateTime lastChange, string lastChanger, bool pushRejected)
            {
                this.uid = uid;
                this.json = json;
                this.referencedNodeIds = referencedNodeIds;
                this.lastChange = lastChange;
                this.lastChanger = lastChanger;
                this.pushRejected = pushRejected;
            }
        }

        public struct UpdatedObj
        {
            public string uid;
            public string json;
            public DateTime lastChange;
            public string lastChanger;
            public bool pushRejected;

            public UpdatedObj(string uid, string json, DateTime lastChange, string lastChanger, bool pushRejected)
            {
                this.uid = uid;
                this.json = json;
                this.lastChange = lastChange;
                this.lastChanger = lastChanger;
                this.pushRejected = pushRejected;
            }
        }

        public struct UpdatedCollection
        {
            public string uid;
            public string[] objectIds;
            public DateTime lastChange;
            public string lastChanger;
            public bool pushRejected;

            public UpdatedCollection(string uid, string[] objectIds, DateTime lastChange, string lastChanger, bool pushRejected)
            {
                this.uid = uid;
                this.objectIds = objectIds;
                this.lastChange = lastChange;
                this.lastChanger = lastChanger;
                this.pushRejected = pushRejected;
            }
        }
    }
}